package se.mdh.ls.assign4;

import java.util.ArrayList;
import java.util.List;

public class Node {
	private char id;
	private int optimalValue = 0;
	private int iteration = -1;
	private Node next = null;
	private List<Path> connectedPaths = new ArrayList<Path>();
	
	public Node(char id) {
		this.id = id;
	}

	public char getId() {
		return id;
	}

	public int getOptimalValue() {
		return optimalValue;
	}

	public int getIteration() {
		return iteration;
	}
	
	public Node getNext() {
		return next;
	}
	
	public List<Path> getConnectedPaths() {
		return connectedPaths;
	}

	public boolean calculateOptimalValue(char destiny, int iteration) {
		Node working;
		int maxValue, auxValue;
		
		if (this.iteration == iteration)
			return true;
		else if (this.iteration < iteration-1)
			return false;
		
		this.iteration = iteration;
		
		if (this.id == destiny)
			return true;
		
		if (connectedPaths.size() == 0) {
			optimalValue = -1;
			return false;
		} 
		
		working = connectedPaths.get(0).getDestiny(this);
		if (!working.calculateOptimalValue(destiny, iteration)) return false;
		maxValue = -connectedPaths.get(0).getDistance() + working.getOptimalValue();
		next = working;

		for (int i = 1; i < connectedPaths.size(); i++) {
			Path p = connectedPaths.get(i);
			working = p.getDestiny(this);
			if (!working.calculateOptimalValue(destiny, iteration)) return false;
			auxValue = -p.getDistance() + working.getOptimalValue();
			
			if (auxValue > maxValue) {
				maxValue = auxValue;
				next = working;
			}
		}
		
		optimalValue = maxValue;
		return true;
	}
}

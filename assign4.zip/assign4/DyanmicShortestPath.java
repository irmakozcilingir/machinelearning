package se.mdh.ls.assign4;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class DyanmicShortestPath {
	public static void main(String[] args) {
		List<Path> pathList = new ArrayList<Path>();
		List<Node> nodeList = new ArrayList<Node>();
		Path newPath;
		int numNodes = 0;
		
		char destiny = 'F';
		int numIterations = 100;
		
		try {
			FileReader fileReader = new FileReader("city1.txt");
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			StringTokenizer tok;
			String line;
			boolean read = false;
			char idA, idB;
			int distance;
			Node nA = null, nB = null;
			
			while ((line = bufferedReader.readLine()) != null) {
				if (read) {
					tok = new StringTokenizer(line, " ");
					
					idA = tok.nextToken().charAt(0);
					idB = tok.nextToken().charAt(0);
					distance = Integer.parseInt(tok.nextToken());
					
					nA = null;
					nB = null;
					for (Node n : nodeList) {
						if (n.getId() == idA) {
							nA = n;
						} else if (n.getId() == idB)
							nB = n;
					}
					
					if (nA == null) {
						nA = new Node(idA);
						nodeList.add(nA);
					}
					if (nB == null) {
						nB = new Node(idB);
						nodeList.add(nB);
					}
					
					newPath = new Path(nA, nB, distance);
					pathList.add(newPath);
					
					nA.getConnectedPaths().add(newPath);
					nB.getConnectedPaths().add(newPath);
						
				} else  {
					if(line.startsWith("TOTAL LOCATIONS: "))
						numNodes = Integer.parseInt(line.substring(17));
				}
				
				if (line.length() == 0) {
					read = true;
				}
			}
			
			bufferedReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("Unable to open file");
		} catch (IOException e) {
			System.out.println("Unable to read file");
		}
		
		if (nodeList.size() != numNodes) {
			System.out.println("Error in the file structure");
			return;
		}
		System.out.println("File read successfully\n");
		
		for (int i = 0; i < numIterations+1; i++) {
			for(Node n : nodeList) {
				if (!n.calculateOptimalValue(destiny, i)) {
					System.out.println("Error in the node structure");
					return;
				}
			}
		}
		
		for (Node n : nodeList) {
			Node next;
			
			System.out.print(n.getId() + " " + n.getIteration() + " " + n.getOptimalValue() + " ");
			
			System.out.print("\t" + n.getId());
			next = n.getNext();
			while (next != null) {
				System.out.print(" -> " + next.getId());
				next = next.getNext();
			}
			System.out.println();
		}
	}
}

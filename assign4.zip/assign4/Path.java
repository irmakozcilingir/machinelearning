package se.mdh.ls.assign4;

public class Path {
	private Node nA, nB;
	private int distance;
	
	public Path(Node nA, Node nB, int distance) {
		this.nA = nA;
		this.nB = nB;
		this.distance = distance;
	}
	
	public Node getNA() {
		return nA;
	}

	public Node getNB() {
		return nB;
	}

	public int getDistance() {
		return distance;
	}

	public boolean connectsNode(char id) {
		if (id == nA.getId() || id == nB.getId())
			return true;
		
		return false;
	}
	
	public Node getDestiny(Node origin) {
		if (nA.getId() == origin.getId())
			return nB;
		else if (nB.getId() == origin.getId())
			return nA;
		else 
			return null;
	}
}

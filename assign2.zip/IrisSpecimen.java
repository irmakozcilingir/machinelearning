package se.mdh.ls.assign2;

public class IrisSpecimen {
	private Attribute sepalLength, sepalWidth, petalLength, petalWidth;
	private int realClass;
	private float firingStrength1, firingStrength2, firingStrength3, firingStrength4;
	private int resultClass;
	
	public IrisSpecimen(float sepalLength, float sepalWidth, float petalLength, float petalWidth, int realClass) {
		this.sepalLength = new Attribute(sepalLength);
		this.sepalWidth = new Attribute(sepalWidth);
		this.petalLength = new Attribute(petalLength);
		this.petalWidth = new Attribute(petalWidth);
		this.realClass = realClass;
	}

	public Attribute getSepalLength() {
		return sepalLength;
	}

	public Attribute getSepalWidth() {
		return sepalWidth;
	}

	public Attribute getPetalLength() {
		return petalLength;
	}

	public Attribute getPetalWidth() {
		return petalWidth;
	}

	public int getRealClass() {
		return realClass;
	}
	
	public int getResultClass() {
		return resultClass;
	}
	
	public void ruleMatching() {
		float auxFiringStrength;
		
		
		firingStrength1 = Math.max(sepalLength.getShortMembership(), sepalLength.getLongMembership());
		
		auxFiringStrength = Math.max(sepalWidth.getMiddleMembership(), sepalWidth.getLongMembership());
		firingStrength1 = Math.min(firingStrength1, auxFiringStrength);
		
		auxFiringStrength = Math.max(petalLength.getMiddleMembership(), petalLength.getLongMembership());
		firingStrength1 = Math.min(firingStrength1, auxFiringStrength);
		
		firingStrength1 = Math.min(firingStrength1, petalWidth.getMiddleMembership());
		
		
		firingStrength2 = Math.max(petalLength.getShortMembership(), petalLength.getMiddleMembership());
		
		firingStrength2 = Math.min(firingStrength2, petalWidth.getShortMembership());
		
		
		firingStrength3 = Math.max(sepalWidth.getShortMembership(), sepalWidth.getMiddleMembership());
		
		firingStrength3 = Math.min(firingStrength3, petalLength.getLongMembership());
		
		firingStrength3 = Math.min(firingStrength3, petalWidth.getLongMembership());
		
		
		firingStrength4 = sepalLength.getMiddleMembership();
		
		auxFiringStrength = Math.max(sepalWidth.getShortMembership(), sepalWidth.getMiddleMembership());
		firingStrength4 = Math.min(firingStrength4, auxFiringStrength);
		
		firingStrength4 = Math.min(firingStrength4, petalLength.getShortMembership());
		
		firingStrength4 = Math.min(firingStrength4, petalWidth.getLongMembership());
	}
	
	public void defuzzification() {
		float maxFiringStrength = Math.max(Math.max(firingStrength1, firingStrength2), Math.max(firingStrength3, firingStrength4));
		
		System.out.println(firingStrength1 + " " + firingStrength2 + " " + firingStrength3 + " " + firingStrength4);
		
		if (maxFiringStrength == firingStrength1 || maxFiringStrength == firingStrength4)
			resultClass = 2;
		else if (maxFiringStrength == firingStrength2)
			resultClass = 1;
		else if (maxFiringStrength == firingStrength3)
			resultClass = 3;
		else
			resultClass = -1;
	}
}

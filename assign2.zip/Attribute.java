package se.mdh.ls.assign2;

public class Attribute {
	private float value, normValue, shortMembership, middleMembership, longMembership;
	public static final float topMiddle = 0.6f;
	
	public Attribute(float value) {
		this.value = value;
	}
	
	public float getShortMembership() {
		return shortMembership;
	}

	public float getMiddleMembership() {
		return middleMembership;
	}

	public float getLongMembership() {
		return longMembership;
	}
	
	public void normFuzzification(float min, float max) {
		normValue = (value - min)/(max - min);
		
		this.assignMembershipValues();
	}
	
	private void assignMembershipValues() {
			shortMembership = Math.max(0, (-1/topMiddle)*normValue+1);
			middleMembership = Math.min((1/topMiddle)*normValue, (-1/(1-topMiddle))+(1/(1-topMiddle)));
			longMembership = Math.max(0, (1/(1-topMiddle))+(-1/(1-topMiddle)));
	}
}

package se.mdh.ls.assign2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class IrisClassification {
	public static void main(String[] args) {
		FileReader fileReader;
		BufferedReader bufferedReader;
		StringTokenizer tok;
		String line;
		IrisSpecimen newSpecimen;
		List<IrisSpecimen> specimens = new ArrayList<IrisSpecimen>();
		float sepalLength, sepalWidth, petalLength, petalWidth;
		int realType;
		float minSepLen = Float.MAX_VALUE, minSepWid = Float.MAX_VALUE, minPetLen = Float.MAX_VALUE, minPetWid = Float.MAX_VALUE;
		float maxSepLen = Float.MIN_VALUE, maxSepWid = Float.MIN_VALUE, maxPetLen = Float.MIN_VALUE, maxPetWid = Float.MIN_VALUE;
		int numCorrect = 0;
		
		try {
			fileReader = new FileReader("IRIS_Data.txt");
			bufferedReader = new BufferedReader(fileReader);

			while ((line = bufferedReader.readLine()) != null) {
				tok = new StringTokenizer(line, " ");

				if ((sepalLength = Float.parseFloat(tok.nextToken())) < minSepLen) minSepLen = sepalLength;
				if (sepalLength > maxSepLen) maxSepLen = sepalLength;
				
				if ((sepalWidth = Float.parseFloat(tok.nextToken())) < minSepWid) minSepWid = sepalWidth;
				if (sepalWidth > maxSepWid) maxSepWid = sepalWidth;
				
				if ((petalLength = Float.parseFloat(tok.nextToken())) < minPetLen) minPetLen = petalLength;
				if (petalLength > maxPetLen) maxPetLen = petalLength;
				
				if ((petalWidth = Float.parseFloat(tok.nextToken())) < minPetWid) minPetWid = petalWidth;
				if (petalWidth > maxPetWid) maxPetWid = petalWidth;

				realType = Integer.parseInt(tok.nextToken());

				newSpecimen = new IrisSpecimen(sepalLength, sepalWidth, petalLength, petalWidth, realType);

				specimens.add(newSpecimen);

			}

			bufferedReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("Unable to open file");
		} catch (IOException e) {
			System.out.println("Unable to read file");
		}

		System.out.println("Iris list read succesfully (" + specimens.size() + " elements)\n");
		System.out.println("Sepal: minLength maxLength minWidth maxWidth");
		System.out.println("\t" + minSepLen + "\t" + maxSepLen + "\t" + minSepWid + "\t" + maxSepWid);
		System.out.println("Petal: minLength maxLength minWidth maxWidth");
		System.out.println("\t" + minPetLen + "\t" + maxPetLen + "\t" + minPetWid + "\t" + maxPetWid);
		
		System.out.println("\nRealClass ResultClass Correct");
		
		for (IrisSpecimen s : specimens) {
			s.getSepalLength().normFuzzification(minSepLen, maxSepLen);
			s.getSepalWidth().normFuzzification(minSepWid, maxSepWid);
			s.getPetalLength().normFuzzification(minPetLen, maxPetLen);
			s.getPetalWidth().normFuzzification(minPetWid, maxPetWid);
			
			s.ruleMatching();
			
			s.defuzzification();
			
			System.out.println(s.getRealClass() + " " + s.getResultClass() + " " + (s.getRealClass() == s.getResultClass()));
			if (s.getRealClass() == s.getResultClass())
				numCorrect++;
		}
		
		System.out.println("\nPercentage of correctness: " + (float) numCorrect/specimens.size());
	}
}
